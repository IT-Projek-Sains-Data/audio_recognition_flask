from flask import Flask, render_template, request, jsonify
import numpy as np
import librosa
from keras.models import load_model
from io import BytesIO

app = Flask(__name__)

# Load the pre-trained model
model = load_model("model.h5")

def predict_audio(file):
    audio_data = librosa.load(file, duration=3, offset=0.5)
    mfcc = np.mean(librosa.feature.mfcc(y=audio_data[0], sr=audio_data[1], n_mfcc=40).T, axis=0)
    label_list = ['baiksekali', 'netral', 'buruk']
    mfcc = np.reshape(mfcc, (1, 40, 1))
    pred = model.predict(mfcc)
    confidence_percentage = int(pred[0][np.argmax(pred)] * 100)
    return {'prediction': label_list[np.argmax(pred)], 'confidence': confidence_percentage}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    if 'file' not in request.files:
        return render_template('index.html', error='No file part')

    files = request.files.getlist('file')
    predictions = []

    for file in files:
        try:
            result = predict_audio(file)
            predictions.append({'filename': file.filename, 'result': result})
        except Exception as e:
            predictions.append({'filename': file.filename, 'error': str(e)})

    return render_template('index.html', predictions=predictions)

if __name__ == '__main__':
    app.run(debug=True)
